Title: ListView Editable SubItems
Description: Create a listview with editable subitems, without using the MSFlexgrid control. Stand alone module can be used for any project where you need this kind of functionality. It doesn't use subclassing, so it will not make your project unstable.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=30494&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

This is a sample ActiveX Contorl (User Control), which acts as 
a date object.

Refer to 'Implementation' to sample how this custom-made object is 
being utilized and subsequently understand the needs for its creation.